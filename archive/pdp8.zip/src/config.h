// config.h
// Some definitions for the used hardware

#define WIFI_SSID     "ADSL-11"                                 // Enter your WiFi credentials here
#define WIFI_PASSWORD "DEADC0DE11"
#define SD_CS         5                                         // CS pin for SD card
#define TIMEZONE      "CET-1:00:CEST-2:00:00,M3.5.0,M10.5.0"
#define OLEDDISPLAY                                             // OLED support
#define SDA_PIN       4
#define SCL_PIN       15
#define RST_PIN       16



